import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Phone, Menu, X } from 'lucide-react';

export default function Header({ logoUrl }) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { href: '#services', text: 'Services' },
    { href: '#why-choose-us', text: 'Why Us' },
    { href: '#testimonials', text: 'Reviews' },
    { href: '#contact', text: 'Free Estimate' },
  ];

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-lg py-3' : 'bg-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <a href="#" aria-label="Atticali Home">
            <img 
              src={logoUrl} 
              alt="Atticali Logo" 
              className={`transition-all duration-300 ${isScrolled ? 'h-12 sm:h-14' : 'h-16 sm:h-20'}`} 
            />
          </a>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-6 items-center">
            {navLinks.map(link => (
              <a 
                key={link.text}
                href={link.href} 
                className={`text-sm font-semibold transition-colors ${
                  isScrolled ? 'text-gray-700 hover:text-emerald-600' : 'text-gray-800 hover:text-emerald-700'
                }`}
              >
                {link.text}
              </a>
            ))}
            <a href="tel:4086649888">
              <Button 
                variant="outline"
                size="sm"
                className="border-emerald-600 text-emerald-600 hover:bg-emerald-50 hover:text-emerald-700"
              >
                <Phone className="w-4 h-4 mr-2" />
                Call / Text
              </Button>
            </a>
          </nav>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className={`p-2 rounded-md ${isScrolled ? 'text-gray-700' : 'text-gray-800'}`}
              aria-label="Toggle mobile menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white shadow-lg pb-4">
          <nav className="flex flex-col space-y-3 px-4 pt-3">
            {navLinks.map(link => (
              <a 
                key={link.text}
                href={link.href} 
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-gray-700 hover:text-emerald-600 font-medium py-2 px-2 rounded-md hover:bg-emerald-50"
              >
                {link.text}
              </a>
            ))}
            <a href="tel:4086649888">
              <Button 
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white mt-2"
              >
                <Phone className="w-4 h-4 mr-2" />
                Call / Text (408) 664-9888
              </Button>
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}