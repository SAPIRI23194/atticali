
import React, { useState, useEffect } from "react";
import Header from "../components/layout/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Check, 
  Phone, 
  Star, 
  ShieldCheck,
  Award, 
  HeartHandshake,
  FileText,
  BadgeCheck,
  Mail,
  MapPin,
  ChevronLeft,
  ChevronRight,
  Users,
  Sparkles,
  Layers,
  CheckCircle
} from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { SendEmail } from "@/api/integrations";

export default function Home() {
  const [currentTestimonialIndex, setCurrentTestimonialIndex] = useState(0);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    service: '',
    preferredTime: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  const logoUrl = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/20e14e943_atticalilogo.png";

  // SEO metadata setup
  useEffect(() => {
    // Set page title
    document.title = "Atticali - Bay Area Attic & Crawl Space Cleaning | Rodent Proofing | Insulation Services";
    
    // Set meta description
    const metaDescription = document.querySelector('meta[name="description"]') || document.createElement('meta');
    metaDescription.name = "description";
    metaDescription.content = "Professional attic & crawl space cleaning, rodent proofing, and insulation services in Bay Area. Licensed & insured. Free estimates. Call (408) 664-9888";
    if (!document.querySelector('meta[name="description"]')) {
      document.head.appendChild(metaDescription);
    }

    // Set meta keywords
    const metaKeywords = document.querySelector('meta[name="keywords"]') || document.createElement('meta');
    metaKeywords.name = "keywords";
    metaKeywords.content = "attic cleaning, crawl space cleaning, rodent proofing, insulation installation, bay area, san jose, milpitas, pest control";
    if (!document.querySelector('meta[name="keywords"]')) {
      document.head.appendChild(metaKeywords);
    }

    // Open Graph metadata
    const ogTitle = document.querySelector('meta[property="og:title"]') || document.createElement('meta');
    ogTitle.setAttribute('property', 'og:title');
    ogTitle.content = "Atticali - Bay Area's Trusted Attic & Crawl Space Specialists";
    if (!document.querySelector('meta[property="og:title"]')) {
      document.head.appendChild(ogTitle);
    }

    const ogDescription = document.querySelector('meta[property="og:description"]') || document.createElement('meta');
    ogDescription.setAttribute('property', 'og:description');
    ogDescription.content = "Professional attic & crawl space cleaning, rodent proofing, and insulation services. Licensed & insured with guaranteed satisfaction.";
    if (!document.querySelector('meta[property="og:description"]')) {
      document.head.appendChild(ogDescription);
    }

    const ogType = document.querySelector('meta[property="og:type"]') || document.createElement('meta');
    ogType.setAttribute('property', 'og:type');
    ogType.content = "website";
    if (!document.querySelector('meta[property="og:type"]')) {
      document.head.appendChild(ogType);
    }

    const ogImage = document.querySelector('meta[property="og:image"]') || document.createElement('meta');
    ogImage.setAttribute('property', 'og:image');
    ogImage.content = logoUrl; // Use the new logo URL
    if (!document.querySelector('meta[property="og:image"]')) {
      document.head.appendChild(ogImage);
    }

    // Structured data for local business
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Atticali",
      "image": logoUrl, // Add logo to structured data
      "description": "Professional attic and crawl space cleaning, rodent proofing, and insulation services in Bay Area",
      "telephone": "(408) 664-9888",
      "email": "info@atticali.com",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Milpitas",
        "addressRegion": "CA",
        "addressCountry": "US"
      },
      "areaServed": ["San Jose", "Milpitas", "Fremont", "Santa Clara", "Sunnyvale", "Mountain View"],
      "serviceType": ["Attic Cleaning", "Crawl Space Cleaning", "Rodent Proofing", "Insulation Installation"],
      "priceRange": "$$"
    };

    let script = document.querySelector('script[type="application/ld+json"]');
    if (!script) {
      script = document.createElement('script');
      script.type = 'application/ld+json';
      document.head.appendChild(script);
    }
    script.textContent = JSON.stringify(structuredData);

  }, []);

  const services = [
    {
      title: "Rodent Proofing & Prevention",
      uspTitle: "What Makes Us Different:",
      icon: Users,
      items: [
        "We don't just block entry points – we find the source.",
        "Humane, safe and long-lasting methods – no shortcuts.",
        "Transparent diagnosis with clear explanations.",
        "We stand behind our work with follow-up checkups if needed."
      ]
    },
    {
      title: "Attic & Crawl Space Cleaning & Decontamination",
      uspTitle: "Why Homeowners Choose Us:",
      icon: Check,
      items: [
        "Fast, thorough and respectful of your space.",
        "We show you what we remove — no hidden mess left behind.",
        "Non-toxic products safe for families and pets.",
        "Honest feedback: if you don't need a full cleanup, we'll tell you."
      ]
    },
    {
      title: "Insulation Installation & Removal",
      uspTitle: "The Atticali Standard:",
      icon: Award,
      items: [
        "We remove old insulation the right way — clean, complete, and safe.",
        "Customized energy-efficient solutions that fit your home.",
        "Clear pricing — no upsells, no games.",
        "We help you understand where energy is lost and how we fix it."
      ]
    }
  ];

  const trustIndicators = [
    { icon: Award, text: "Diamond Certified Local Company" },
    { icon: ShieldCheck, text: "Licensed & Insured" },
    { icon: HeartHandshake, text: "Honest, Reliable Service" },
    { icon: FileText, text: "Clear and Transparent Pricing - No Hidden Fees" },
    { icon: BadgeCheck, text: "Warranty Backed Work" }
  ];

  const testimonials = [
    {
      name: "Sarah M.",
      location: "San Jose",
      text: "Atticali did an amazing job cleaning our attic and sealing entry points. No more rodent issues and our energy bills went down significantly!",
      rating: 5
    },
    {
      name: "Mike R.",
      location: "Milpitas",
      text: "Professional, honest, and thorough. They explained everything clearly and the pricing was exactly as quoted. Highly recommend!",
      rating: 5
    },
    {
      name: "Jennifer L.",
      location: "Fremont",
      text: "Fast response, quality work, and excellent customer service. Our crawl space looks brand new and the air quality has improved dramatically.",
      rating: 5
    },
    {
      name: "David K.",
      location: "Santa Clara",
      text: "The insulation work was top-notch. I've noticed a real difference in my home's temperature consistency. Great team!",
      rating: 5
    },
    {
      name: "Linda P.",
      location: "Sunnyvale",
      text: "They were so respectful of my property and did a fantastic cleanup job. I feel much better knowing my attic is clean and secure.",
      rating: 5
    }
  ];
  
  const [reviewsToShow, setReviewsToShow] = useState(1);

  useEffect(() => {
    const updateReviewsCount = () => {
      if (window.innerWidth >= 1024) { // lg
        setReviewsToShow(2);
      } else if (window.innerWidth >= 768) { // md
        setReviewsToShow(2);
      } else { // sm
        setReviewsToShow(1);
      }
    };
    updateReviewsCount();
    window.addEventListener('resize', updateReviewsCount);
    return () => window.removeEventListener('resize', updateReviewsCount);
  }, []);

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Prepare email content
      const emailBody = `
New Lead from Google Campaign Landing Page

Contact Information:
- Name: ${formData.name}
- Phone: ${formData.phone}
- Email: ${formData.email}

Service Request:
- Service Needed: ${formData.service || 'Not specified'}
- Preferred Appointment Time: ${formData.preferredTime || 'Not specified'}

Message:
${formData.message || 'No additional message provided'}

Please contact this lead as soon as possible.
      `.trim();

      // Send email
      await SendEmail({
        to: 'info@atticali.com',
        subject: 'New Lead Google Campaign LP',
        body: emailBody
      });

      // Show success message
      setShowSuccessMessage(true);
      
      // Reset form
      setFormData({
        name: '',
        phone: '',
        email: '',
        service: '',
        preferredTime: '',
        message: ''
      });

      // Hide success message after 8 seconds
      setTimeout(() => {
        setShowSuccessMessage(false);
      }, 8000);
      
    } catch (error) {
      console.error('Error submitting form:', error);
      // You could add error handling here
    } finally {
      setIsSubmitting(false);
    }
  };

  const nextTestimonial = () => {
    setCurrentTestimonialIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentTestimonialIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };
  
  const getVisibleTestimonials = () => {
    const visible = [];
    for (let i = 0; i < reviewsToShow; i++) {
      visible.push(testimonials[(currentTestimonialIndex + i) % testimonials.length]);
    }
    return visible;
  };

  // Assigning more specific icons for services
  const serviceIcons = {
    "Rodent Proofing & Prevention": ShieldCheck,
    "Attic & Crawl Space Cleaning & Decontamination": Sparkles,
    "Insulation Installation & Removal": Layers
  };

  // Comprehensive Bay Area service areas for SEO
  const serviceAreas = [
    "San Jose", "Milpitas", "Fremont", "Santa Clara", "Sunnyvale", "Mountain View",
    "Los Altos", "Los Altos Hills", "Saratoga", "Campbell", "Morgan Hill", "Gilroy",
    "Pleasanton", "Dublin", "San Ramon", "Danville", "Walnut Creek", "Lafayette",
    "Alamo", "Orinda", "Cupertino", "Menlo Park", "Atherton", "Hillsborough",
    "San Carlos", "Redwood City", "Union City", "Hayward", "Newark", "Belmont",
    "San Mateo", "Stanford"
  ];


  return (
    <div className="min-h-screen bg-white">
      <Header logoUrl={logoUrl} />
      
      <section id="hero" className="relative bg-gradient-to-br from-emerald-50 to-white pt-32 sm:pt-36 md:pt-40 pb-16 px-4">
        <div className="max-w-6xl mx-auto text-center">
          
          <Badge className="mb-6 bg-emerald-100 text-emerald-800 border-emerald-200 px-4 py-2 text-sm font-medium">
            Bay Area's Trusted Attic Specialists
          </Badge>
          
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
            Keeping Your Attic & Crawl Space<br />
            <span className="text-emerald-700">Clean, Safe & Energy-Efficient</span>
          </h1>
          
          <h2 className="text-xl md:text-2xl text-gray-600 mb-8 max-w-4xl mx-auto leading-relaxed">
            <span className="font-semibold text-emerald-700">Rodent Proofing</span> • 
            <span className="font-semibold text-emerald-700"> Insulation</span> • 
            <span className="font-semibold text-emerald-700"> Attic & Crawl Space Cleaning</span>
            <br />By Our Professional Team
          </h2>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <a href="#contact">
              <Button 
                size="lg" 
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 w-full sm:w-auto"
                aria-label="Book free attic inspection and estimate"
              >
                Book Free Estimate & Inspection
              </Button>
            </a>
            
            <a href="tel:4086649888">
              <Button 
                variant="outline" 
                size="lg"
                className="border-2 border-emerald-600 text-emerald-600 hover:bg-emerald-50 px-8 py-4 text-lg font-semibold rounded-xl w-full sm:w-auto"
                aria-label="Call or Text Atticali at (408) 664-9888"
              >
                <Phone className="w-5 h-5 mr-2" />
                Call / Text (408) 664-9888
              </Button>
            </a>
          </div>

          {/* Updated Hero Stats - Redesigned Layout */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-8 max-w-5xl mx-auto text-left md:text-center">
            <div className="flex md:flex-col items-center md:text-center">
              <Users className="w-10 h-10 text-emerald-600 mr-4 md:mr-0 md:mb-2 flex-shrink-0" />
              <div>
                <p className="text-xl font-bold text-gray-800">500+ Happy Customers</p>
                <p className="text-sm text-gray-600">Trusted across the Bay Area</p>
              </div>
            </div>
            <div className="flex md:flex-col items-center md:text-center">
              <Award className="w-10 h-10 text-emerald-600 mr-4 md:mr-0 md:mb-2 flex-shrink-0" />
              <div>
                <p className="text-xl font-bold text-gray-800">10+ Years Experience</p>
                <p className="text-sm text-gray-600">Expert attic & crawl space solutions</p>
              </div>
            </div>
            <div className="flex md:flex-col items-center md:text-center">
              <FileText className="w-10 h-10 text-emerald-600 mr-4 md:mr-0 md:mb-2 flex-shrink-0" />
              <div>
                <p className="text-xl font-bold text-gray-800">Clear & Honest Pricing</p>
                <p className="text-sm text-gray-600">No surprises, fair estimates, no hidden fees.</p>
              </div>
            </div>
            <div className="flex md:flex-col items-center md:text-center">
              <Check className="w-10 h-10 text-emerald-600 mr-4 md:mr-0 md:mb-2 flex-shrink-0" />
              <div>
                <p className="text-xl font-bold text-gray-800">Free Professional Inspection + Fast Scheduling</p>
                <p className="text-sm text-gray-600">Honest, expert evaluation. No charge, no pressure.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <main>
        <section id="services" className="py-20 px-4 bg-gray-50" aria-labelledby="services-heading">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 id="services-heading" className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                What We Do
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto"> {/* Increased max-width for slightly longer subtext */}
                Comprehensive attic and crawl space solutions tailored to protect your Bay Area home, enhance energy efficiency, and ensure a healthy living environment.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {services.map((service, index) => {
                const ServiceIcon = serviceIcons[service.title] || Check; // Fallback to Check icon
                return (
                  <Card key={index} className="bg-white border-0 shadow-xl hover:shadow-2xl transition-all duration-300 rounded-xl overflow-hidden flex flex-col">
                    <CardContent className="p-8 flex-grow flex flex-col">
                      <div className="flex items-center mb-5">
                        <ServiceIcon className="w-8 h-8 text-emerald-600 mr-3 flex-shrink-0" />
                        <h3 className="text-2xl font-bold text-gray-900 leading-tight">
                          {service.title}
                        </h3>
                      </div>
                      
                      <h4 className="text-lg font-semibold text-emerald-700 mb-3 mt-2">
                        {service.uspTitle}
                      </h4>
                      <ul className="space-y-3 text-gray-700 flex-grow">
                        {service.items.map((item, itemIndex) => (
                          <li key={itemIndex} className="flex items-start gap-3">
                            <Check className="w-5 h-5 text-emerald-600 mt-1 flex-shrink-0" aria-hidden="true" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* Why Choose Us Section - Updated */}
        <section id="why-choose-us" className="py-16 px-4 bg-emerald-700" aria-labelledby="trust-heading">
          <div className="max-w-6xl mx-auto">
            <h2 id="trust-heading" className="text-3xl font-bold text-white text-center mb-12">
              Why Choose Atticali?
            </h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 md:gap-8">
              {trustIndicators.map((indicator, index) => (
                <div key={index} className="text-center p-4 bg-emerald-600 rounded-lg shadow-md">
                  <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4">
                    <indicator.icon className="w-8 h-8 text-emerald-700" aria-hidden="true" />
                  </div>
                  <p className="text-white font-medium text-sm md:text-base">{indicator.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials Section - Updated */}
        <section id="testimonials" className="py-20 px-4 bg-white" aria-labelledby="testimonials-heading">
          <div className="max-w-5xl mx-auto"> {/* Adjusted max-width for potentially wider carousel */}
            <div className="text-center mb-16">
              <h2 id="testimonials-heading" className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                What Our Customers Say
              </h2>
              <p className="text-xl text-gray-600">
                Real reviews from satisfied Bay Area homeowners
              </p>
            </div>

            <div className="relative">
              <div className={`grid grid-cols-1 ${reviewsToShow === 2 ? 'md:grid-cols-2' : ''} gap-8`}>
                <AnimatePresence initial={false} custom={currentTestimonialIndex}>
                  {getVisibleTestimonials().map((testimonial, index) => (
                    <motion.div
                      key={testimonial.name + currentTestimonialIndex + index} // Ensure unique key for re-renders
                      custom={currentTestimonialIndex}
                      initial={{ opacity: 0, x: 100 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -100 }}
                      transition={{ duration: 0.5 }}
                    >
                      <Card className="bg-gray-50 border-0 shadow-lg rounded-xl overflow-hidden h-full flex flex-col">
                        <CardContent className="p-8 md:p-10 text-center flex-grow flex flex-col justify-between">
                          <div>
                            <div className="flex justify-center mb-4" aria-label={`${testimonial.rating} star rating`}>
                              {[...Array(testimonial.rating)].map((_, i) => (
                                <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" aria-hidden="true" />
                              ))}
                            </div>
                            <blockquote className="text-md md:text-lg text-gray-700 mb-4 leading-relaxed italic">
                              "{testimonial.text}"
                            </blockquote>
                          </div>
                          <div>
                            <div className="text-md font-semibold text-gray-900 mt-4">
                              {testimonial.name}
                            </div>
                            <div className="text-emerald-600 text-sm">
                              {testimonial.location}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              {testimonials.length > reviewsToShow && (
                <div className="flex justify-center gap-4 mt-8">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={prevTestimonial}
                    className="rounded-full border-emerald-600 text-emerald-600 hover:bg-emerald-50"
                    aria-label="Previous testimonial"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={nextTestimonial}
                    className="rounded-full border-emerald-600 text-emerald-600 hover:bg-emerald-50"
                    aria-label="Next testimonial"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </Button>
                </div>
              )}
            </div>
          </div>
        </section>


        {/* Lead Form Section */}
        <section id="contact" className="py-20 px-4 bg-emerald-50" aria-labelledby="contact-heading">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-12">
              <h2 id="contact-heading" className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Get Your Free Estimate
              </h2>
              <p className="text-xl text-gray-600">
                Schedule your inspection today and receive a detailed quote
              </p>
            </div>

            {showSuccessMessage && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-8"
              >
                <Alert className="bg-green-50 border-green-200 text-green-800">
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription className="font-medium">
                    Thank you for your message! Our team member will contact you ASAP to schedule your free inspection.
                  </AlertDescription>
                </Alert>
              </motion.div>
            )}

            <Card className="bg-white border-0 shadow-xl rounded-xl overflow-hidden">
              <CardContent className="p-8">
                <form onSubmit={handleFormSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-semibold text-gray-700 mb-2">
                        Full Name *
                      </label>
                      <Input
                        id="name"
                        name="name"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="phone" className="block text-sm font-semibold text-gray-700 mb-2">
                        Phone Number *
                      </label>
                      <Input
                        id="phone"
                        name="phone"
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData({...formData, phone: e.target.value})}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2">
                      Email Address *
                    </label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="service" className="block text-sm font-semibold text-gray-700 mb-2">
                        Service Needed
                      </label>
                      <select
                        id="service"
                        name="service"
                        value={formData.service}
                        onChange={(e) => setFormData({...formData, service: e.target.value})}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                      >
                        <option value="">Select a service...</option>
                        <option value="rodent-proofing">Rodent Proofing & Prevention</option>
                        <option value="cleaning">Attic & Crawl Space Cleaning</option>
                        <option value="insulation">Insulation Installation</option>
                        <option value="inspection">General Inspection</option>
                        <option value="other">Other</option>
                      </select>
                    </div>

                    <div>
                      <label htmlFor="preferredTime" className="block text-sm font-semibold text-gray-700 mb-2">
                        Preferred Appointment Time
                      </label>
                      <select
                        id="preferredTime"
                        name="preferredTime"
                        value={formData.preferredTime}
                        onChange={(e) => setFormData({...formData, preferredTime: e.target.value})}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                      >
                        <option value="">Select preferred time...</option>
                        <option value="morning">Morning (8AM - 12PM)</option>
                        <option value="afternoon">Afternoon (12PM - 5PM)</option>
                        <option value="evening">Evening (5PM - 8PM)</option>
                        <option value="weekend">Weekend</option>
                        <option value="flexible">Flexible</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-semibold text-gray-700 mb-2">
                      Tell us about your project
                    </label>
                    <Textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={(e) => setFormData({...formData, message: e.target.value})}
                      rows={4}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                      placeholder="Describe your attic or crawl space concerns..."
                    />
                  </div>

                  <Button
                    type="submit"
                    size="lg"
                    disabled={isSubmitting}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-4 text-lg font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50"
                  >
                    {isSubmitting ? 'Sending...' : 'Get My Free Estimate'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      {/* Sticky Mobile CTA - Updated Phone Button Text */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-3 md:hidden z-40 shadow-lg"> {/* Reduced z-index slightly */}
        <div className="flex gap-3">
          <a href="#contact" className="flex-1">
            <Button
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 rounded-lg text-sm"
              aria-label="Get free estimate"
            >
              Book Free Estimate
            </Button>
          </a>
          <a href="tel:4086649888" className="flex-1">
            <Button
              variant="outline"
              className="w-full border-emerald-600 text-emerald-600 hover:bg-emerald-50 py-3 rounded-lg text-sm flex items-center justify-center"
              aria-label="Call or Text (408) 664-9888"
            >
              <Phone className="w-4 h-4 mr-1 sm:mr-2" />
              <span className="truncate">Call/Text</span> {/* Truncate for very small screens */}
            </Button>
          </a>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 mb-8 items-start">
            <div>
              <img 
                src={logoUrl} 
                alt="Atticali Logo" 
                className="mb-4 h-20"
              />
              <p className="text-gray-300 mb-4 text-sm">
                Bay Area's trusted attic and crawl space specialists. Keeping your home clean, safe, and energy-efficient.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
              <address className="space-y-3 text-gray-300 not-italic text-sm">
                <div className="flex items-center gap-3">
                  <Phone className="w-4 h-4" aria-hidden="true" />
                  <a href="tel:4086649888" className="hover:text-emerald-400">(408) 664-9888</a>
                </div>
                <div className="flex items-center gap-3">
                  <Mail className="w-4 h-4" aria-hidden="true" />
                  <a href="mailto:info@atticali.com" className="hover:text-emerald-400">info@atticali.com</a>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin className="w-4 h-4" aria-hidden="true" />
                  <span>Milpitas, CA</span>
                </div>
              </address>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Areas We Serve</h4>
              <div className="text-gray-300 space-y-1 text-sm grid grid-cols-2 gap-x-4">
                {serviceAreas.map((area, index) => (
                  <div key={index} className="py-0.5">{area}</div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-700 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; {new Date().getFullYear()} Atticali. All rights reserved. Licensed & Insured.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
